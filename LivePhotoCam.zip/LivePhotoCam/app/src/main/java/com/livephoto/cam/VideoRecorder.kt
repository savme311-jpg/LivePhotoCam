package com.livephoto.cam

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.net.Uri
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import android.view.Surface
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/**
 * Records whatever the renderer draws (second pass into the encoder's Surface, same GL context)
 * + microphone audio, into Movies/LivePhotoCam as H.264/AAC MP4.
 */
class VideoRecorder(
    ctx: Context,
    private val w: Int,
    private val h: Int,
    withMic: Boolean,
    private val onDone: (Uri?) -> Unit
) {
    private val tag = "VideoRecorder"
    private val resolver = ctx.contentResolver
    private val uri: Uri
    private val pfd: ParcelFileDescriptor
    private val muxer: MediaMuxer
    private val videoEnc: MediaCodec
    private val inputSurface: Surface
    private var audioEnc: MediaCodec? = null
    private var audioRec: AudioRecord? = null
    private val startNs = System.nanoTime()
    private val started = CountDownLatch(1)
    private var expectedTracks = 1
    private var tracksAdded = 0
    private var muxStarted = false
    @Volatile private var stopping = false

    private var eglDisplay: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var vThread: Thread? = null
    private var aThread: Thread? = null

    init {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "LivePhoto_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/LivePhotoCam")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("MediaStore insert failed")
        pfd = resolver.openFileDescriptor(uri, "rw") ?: throw IllegalStateException("Cannot open output")
        muxer = MediaMuxer(pfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 12_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        videoEnc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        videoEnc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inputSurface = videoEnc.createInputSurface()
        videoEnc.start()
        if (withMic) setupAudio()
    }

    @SuppressLint("MissingPermission")
    private fun setupAudio() {
        try {
            val rate = 44100
            val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minBuf, 8192) * 2
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return }
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            enc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            rec.startRecording()
            audioRec = rec
            audioEnc = enc
            expectedTracks = 2
        } catch (e: Exception) {
            Log.w(tag, "Audio disabled", e)
        }
    }

    /** GL thread, with the GLSurfaceView context current. */
    fun attachEgl() {
        eglDisplay = EGL14.eglGetCurrentDisplay()
        eglContext = EGL14.eglGetCurrentContext()
        val cfgId = IntArray(1)
        EGL14.eglQueryContext(eglDisplay, eglContext, EGL14.EGL_CONFIG_ID, cfgId, 0)
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        EGL14.eglChooseConfig(
            eglDisplay, intArrayOf(EGL14.EGL_CONFIG_ID, cfgId[0], EGL14.EGL_NONE), 0,
            configs, 0, 1, num, 0
        )
        eglSurface = EGL14.eglCreateWindowSurface(
            eglDisplay, configs[0], inputSurface, intArrayOf(EGL14.EGL_NONE), 0
        )
    }

    fun start() {
        vThread = Thread({ videoLoop() }, "rec-video").also { it.start() }
        if (audioEnc != null) aThread = Thread({ audioLoop() }, "rec-audio").also { it.start() }
    }

    /** GL thread: render one frame into the encoder surface. */
    fun draw(render: () -> Unit) {
        if (stopping || eglSurface == EGL14.EGL_NO_SURFACE) return
        val prevDraw = EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW)
        val prevRead = EGL14.eglGetCurrentSurface(EGL14.EGL_READ)
        try {
            EGL14.eglMakeCurrent(eglDisplay, eglSurface, eglSurface, eglContext)
            render()
            EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, System.nanoTime() - startNs)
            EGL14.eglSwapBuffers(eglDisplay, eglSurface)
        } finally {
            EGL14.eglMakeCurrent(eglDisplay, prevDraw, prevRead, eglContext)
        }
    }

    /** GL thread. */
    fun stop() {
        if (stopping) return
        stopping = true
        try { videoEnc.signalEndOfInputStream() } catch (_: Exception) {}
        try { EGL14.eglDestroySurface(eglDisplay, eglSurface) } catch (_: Exception) {}
        eglSurface = EGL14.EGL_NO_SURFACE
        Thread {
            try { vThread?.join(); aThread?.join() } catch (_: InterruptedException) {}
            finish()
        }.start()
    }

    // ---------- muxer ----------
    @Synchronized
    private fun addTrack(fmt: MediaFormat): Int {
        val t = muxer.addTrack(fmt)
        tracksAdded++
        if (tracksAdded == expectedTracks) {
            muxer.start()
            muxStarted = true
            started.countDown()
        }
        return t
    }

    private fun write(track: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (!started.await(5, TimeUnit.SECONDS)) return
        synchronized(this) { if (muxStarted) muxer.writeSampleData(track, buf, info) }
    }

    private fun videoLoop() {
        val info = MediaCodec.BufferInfo()
        var track = -1
        var idle = 0
        try {
            while (true) {
                val idx = videoEnc.dequeueOutputBuffer(info, 10_000)
                when {
                    idx == MediaCodec.INFO_TRY_AGAIN_LATER -> { if (stopping && ++idle > 300) return }
                    idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> track = addTrack(videoEnc.outputFormat)
                    idx >= 0 -> {
                        val buf = videoEnc.getOutputBuffer(idx)
                        if (buf != null && info.size > 0 && track >= 0 &&
                            (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                        ) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            write(track, buf, info)
                        }
                        videoEnc.releaseOutputBuffer(idx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(tag, "video loop", e)
        }
    }

    private fun audioLoop() {
        val rec = audioRec ?: return
        val enc = audioEnc ?: return
        val info = MediaCodec.BufferInfo()
        var track = -1
        var eosSent = false
        var lastPts = -1L
        var idle = 0
        try {
            while (true) {
                if (!eosSent) {
                    val inIdx = enc.dequeueInputBuffer(0)
                    if (inIdx >= 0) {
                        val ib = enc.getInputBuffer(inIdx)!!
                        ib.clear()
                        if (stopping) {
                            enc.queueInputBuffer(inIdx, 0, 0, (System.nanoTime() - startNs) / 1000,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            eosSent = true
                        } else {
                            val n = rec.read(ib, min(ib.remaining(), 2048))
                            if (n > 0) {
                                var pts = (System.nanoTime() - startNs) / 1000 - (n / 2) * 1_000_000L / 44100
                                if (pts < 0) pts = 0
                                if (pts <= lastPts) pts = lastPts + 1
                                lastPts = pts
                                enc.queueInputBuffer(inIdx, 0, n, pts, 0)
                            } else {
                                enc.queueInputBuffer(inIdx, 0, 0, max(lastPts + 1, 0L), 0)
                            }
                        }
                    }
                }
                var idx = enc.dequeueOutputBuffer(info, 5_000)
                while (idx != MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = addTrack(enc.outputFormat)
                    } else if (idx >= 0) {
                        val ob = enc.getOutputBuffer(idx)
                        if (ob != null && info.size > 0 && track >= 0 &&
                            (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                        ) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            write(track, ob, info)
                        }
                        enc.releaseOutputBuffer(idx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                    }
                    idx = enc.dequeueOutputBuffer(info, 0)
                }
                if (stopping && eosSent && ++idle > 600) return
            }
        } catch (e: Exception) {
            Log.e(tag, "audio loop", e)
        } finally {
            try { rec.stop() } catch (_: Exception) {}
        }
    }

    private fun finish() {
        var ok = false
        try {
            synchronized(this) { if (muxStarted) { muxer.stop(); ok = true } }
        } catch (e: Exception) { Log.e(tag, "muxer stop", e) }
        try { muxer.release() } catch (_: Exception) {}
        try { videoEnc.stop(); videoEnc.release() } catch (_: Exception) {}
        try { audioEnc?.stop(); audioEnc?.release() } catch (_: Exception) {}
        try { audioRec?.release() } catch (_: Exception) {}
        try { inputSurface.release() } catch (_: Exception) {}
        try { pfd.close() } catch (_: Exception) {}
        try {
            if (ok) {
                resolver.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
            } else {
                resolver.delete(uri, null, null)
            }
        } catch (_: Exception) {}
        onDone(if (ok) uri else null)
    }
}
