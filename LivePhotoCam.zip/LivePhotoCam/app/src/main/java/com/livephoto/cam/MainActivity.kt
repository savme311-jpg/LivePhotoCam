package com.livephoto.cam

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import java.util.concurrent.Executors
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private val TAG = "MainActivity"
    private lateinit var glView: GLSurfaceView
    private lateinit var status: TextView
    private lateinit var btnRec: Button
    private val renderer = AnimRenderer()
    private var tracker: FaceTracker? = null
    private var recording = false
    private val worker = Executors.newSingleThreadExecutor()

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadPhoto(uri)
    }
    private val askPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted ->
        if (granted[Manifest.permission.CAMERA] == true) startTracking()
        else setStatus("Camera permission is required")
    }

    /** RGBA8888 + EGL_RECORDABLE_ANDROID so the same context can also render into the video encoder. */
    private class RecordableChooser : GLSurfaceView.EGLConfigChooser {
        override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
            for (rec in intArrayOf(1, 0)) {
                val a = ArrayList<Int>()
                a.addAll(listOf(
                    EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8,
                    EGL10.EGL_ALPHA_SIZE, 8, EGL10.EGL_RENDERABLE_TYPE, 4
                ))
                if (rec == 1) a.addAll(listOf(0x3142, 1))
                a.add(EGL10.EGL_NONE)
                val cfg = arrayOfNulls<EGLConfig>(1)
                val n = IntArray(1)
                if (egl.eglChooseConfig(display, a.toIntArray(), cfg, 1, n) && n[0] > 0) return cfg[0]!!
            }
            throw IllegalStateException("No suitable EGL config")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2)
            setEGLConfigChooser(RecordableChooser())
            setRenderer(renderer)
            renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        }
        renderer.statusListener = { s -> setStatus(s) }

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(glView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 14f; text = "Tap Photo to choose a face photo"
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnPick = Button(this).apply { text = "Photo"; setOnClickListener { pickPhoto.launch("image/*") } }
        val btnCal = Button(this).apply {
            text = "Recenter"
            setOnClickListener { renderer.recalibrate(); glView.requestRender() }
        }
        btnRec = Button(this).apply { text = "● Rec"; setOnClickListener { toggleRecord() } }
        for (b in listOf(btnPick, btnCal, btnRec)) row.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 12, 24, 16)
            setBackgroundColor(0x99000000.toInt())
        }
        bar.addView(status)
        bar.addView(row)
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)

        askPerms.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    private fun setStatus(s: String) = runOnUiThread { status.text = s }

    private fun startTracking() {
        if (tracker != null) return
        tracker = FaceTracker(
            applicationContext,
            { f -> renderer.face = f; glView.requestRender() },
            { m -> setStatus(m) }
        ).also { it.start(this) }
    }

    // ---------- photo ----------
    private fun loadPhoto(uri: Uri) {
        setStatus("Analysing photo…")
        worker.execute {
            try {
                val bmp = decode(uri)
                val lm = detectFace(bmp)
                if (lm == null || lm.size < 468) {
                    setStatus("No face found — use a clear, front-facing photo")
                    return@execute
                }
                renderer.setPhoto(PhotoPrep.build(bmp, lm))
                glView.requestRender()
                setStatus("Photo ready — look at the camera with a neutral face")
            } catch (e: Throwable) {
                Log.e(TAG, "loadPhoto", e)
                setStatus("Couldn't load photo: ${e.message}")
            }
        }
    }

    private fun decode(uri: Uri): Bitmap {
        val src = ImageDecoder.createSource(contentResolver, uri)
        return ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE   // also applies EXIF rotation
            val maxSide = max(info.size.width, info.size.height)
            var sample = 1
            while (maxSide / sample > 1400) sample *= 2
            decoder.setTargetSampleSize(sample)
        }
    }

    private fun detectFace(bmp: Bitmap): List<NormalizedLandmark>? {
        val base = BaseOptions.builder().setModelAssetPath("face_landmarker.task").setDelegate(Delegate.CPU).build()
        val opts = FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.IMAGE)
            .setNumFaces(1)
            .setMinFaceDetectionConfidence(0.3f)
            .build()
        val lm = FaceLandmarker.createFromOptions(this, opts)
        try {
            return lm.detect(BitmapImageBuilder(bmp).build()).faceLandmarks().firstOrNull()
        } finally {
            lm.close()
        }
    }

    // ---------- recording ----------
    private fun toggleRecord() {
        if (!recording) {
            recording = true
            btnRec.text = "■ Stop"
            val mic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            val app = applicationContext
            glView.queueEvent {
                renderer.startRecording(app, mic) { uri ->
                    runOnUiThread {
                        Toast.makeText(
                            this,
                            if (uri != null) "Saved to Movies/LivePhotoCam" else "Recording failed",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        } else stopRecording()
    }

    private fun stopRecording() {
        recording = false
        btnRec.text = "● Rec"
        glView.queueEvent { renderer.stopRecording() }
    }

    override fun onResume() { super.onResume(); glView.onResume() }

    override fun onPause() {
        if (recording) stopRecording()
        glView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        tracker?.close()
        super.onDestroy()
    }
}
