package com.livephoto.cam

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import android.util.Log
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import java.util.concurrent.Executors

/** One tracked face: smoothed landmarks (normalised, already mirrored like a selfie) + mouth blendshapes. */
class FaceFrame(
    val pts: FloatArray, val w: Int, val h: Int,
    val jawOpen: Float, val funnel: Float, val tsNs: Long
)

class FaceTracker(
    private val context: Context,
    private val onFrame: (FaceFrame?) -> Unit,
    private val onError: (String) -> Unit
) {
    private val tag = "FaceTracker"
    private var landmarker: FaceLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private val camExec = Executors.newSingleThreadExecutor()
    private val initExec = Executors.newSingleThreadExecutor()
    private val filter = OneEuro()
    private var lastTs = 0L
    @Volatile private var closed = false

    fun start(owner: LifecycleOwner) {
        initExec.execute {
            try {
                landmarker = try {
                    build(Delegate.GPU)
                } catch (e: Exception) {
                    Log.w(tag, "GPU delegate failed, using CPU", e)
                    build(Delegate.CPU)
                }
                ContextCompat.getMainExecutor(context).execute { bind(owner) }
            } catch (e: Throwable) {
                Log.e(tag, "init", e)
                onError("Face model failed to load: ${e.message}")
            }
        }
    }

    private fun build(delegate: Delegate): FaceLandmarker {
        val base = BaseOptions.builder()
            .setModelAssetPath("face_landmarker.task")
            .setDelegate(delegate)
            .build()
        val opts = FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(base)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumFaces(1)
            .setMinFaceDetectionConfidence(0.5f)
            .setMinFacePresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setOutputFaceBlendshapes(true)
            .setResultListener(this::onResult)
            .setErrorListener { e -> Log.e(tag, "MediaPipe error", e) }
            .build()
        return FaceLandmarker.createFromOptions(context, opts)
    }

    private fun bind(owner: LifecycleOwner) {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            val p = future.get()
            provider = p
            val selector = ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                ).build()
            val analysis = ImageAnalysis.Builder()
                .setResolutionSelector(selector)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()
            analysis.setAnalyzer(camExec) { proxy -> analyze(proxy) }
            p.unbindAll()
            p.bindToLifecycle(owner, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
        }, ContextCompat.getMainExecutor(context))
    }

    private fun analyze(proxy: ImageProxy) {
        val lm = landmarker
        if (lm == null || closed) { proxy.close(); return }
        try {
            val src = proxy.toBitmap()
            val m = Matrix()
            m.postRotate(proxy.imageInfo.rotationDegrees.toFloat())
            m.postScale(-1f, 1f) // selfie mirror
            val bmp = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
            var ts = SystemClock.uptimeMillis()
            if (ts <= lastTs) ts = lastTs + 1
            lastTs = ts
            lm.detectAsync(BitmapImageBuilder(bmp).build(), ts)
        } catch (e: Exception) {
            Log.e(tag, "analyze", e)
        } finally {
            proxy.close()
        }
    }

    private fun onResult(result: FaceLandmarkerResult, input: MPImage) {
        val faces = result.faceLandmarks()
        if (faces.isEmpty()) {
            filter.reset()
            onFrame(null)
            return
        }
        val lm = faces[0]
        val n = lm.size
        val raw = FloatArray(n * 2)
        for (i in 0 until n) { raw[2 * i] = lm[i].x(); raw[2 * i + 1] = lm[i].y() }
        val now = System.nanoTime()
        val smooth = filter.apply(raw, now / 1e9f)

        var jaw = 0f
        var funnel = 0f
        val bs = result.faceBlendshapes()
        if (bs.isPresent && bs.get().isNotEmpty()) {
            for (c in bs.get()[0]) {
                when (c.categoryName()) {
                    "jawOpen" -> jaw = c.score()
                    "mouthFunnel" -> funnel = c.score()
                }
            }
        }
        onFrame(FaceFrame(smooth, input.width, input.height, jaw, funnel, now))
    }

    fun close() {
        closed = true
        try { provider?.unbindAll() } catch (_: Exception) {}
        try { landmarker?.close() } catch (_: Exception) {}
    }
}
