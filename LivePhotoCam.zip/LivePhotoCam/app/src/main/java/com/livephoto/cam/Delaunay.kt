package com.livephoto.cam

import kotlin.math.max
import kotlin.math.min

/** Bowyer-Watson Delaunay triangulation (runs once per photo). */
object Delaunay {
    private fun key(a: Int, b: Int): Long =
        if (a < b) a.toLong() * 65536L + b else b.toLong() * 65536L + a

    private fun inCircle(xs: DoubleArray, ys: DoubleArray, t: IntArray, px: Double, py: Double): Boolean {
        val ax = xs[t[0]]; val ay = ys[t[0]]
        val bx = xs[t[1]]; val by = ys[t[1]]
        val cx = xs[t[2]]; val cy = ys[t[2]]
        val adx = ax - px; val ady = ay - py
        val bdx = bx - px; val bdy = by - py
        val cdx = cx - px; val cdy = cy - py
        val det = (adx * adx + ady * ady) * (bdx * cdy - cdx * bdy) -
                (bdx * bdx + bdy * bdy) * (adx * cdy - cdx * ady) +
                (cdx * cdx + cdy * cdy) * (adx * bdy - bdx * ady)
        val orient = (bx - ax) * (cy - ay) - (by - ay) * (cx - ax)
        return if (orient > 0) det > 0 else det < 0
    }

    fun triangulate(px: FloatArray, py: FloatArray, n: Int): ShortArray {
        val xs = DoubleArray(n + 3)
        val ys = DoubleArray(n + 3)
        var minX = Double.MAX_VALUE; var minY = Double.MAX_VALUE
        var maxX = -Double.MAX_VALUE; var maxY = -Double.MAX_VALUE
        for (i in 0 until n) {
            xs[i] = px[i].toDouble(); ys[i] = py[i].toDouble()
            minX = min(minX, xs[i]); maxX = max(maxX, xs[i])
            minY = min(minY, ys[i]); maxY = max(maxY, ys[i])
        }
        val d = max(maxX - minX, maxY - minY).coerceAtLeast(1.0) * 50.0
        val cx = (minX + maxX) / 2; val cy = (minY + maxY) / 2
        xs[n] = cx - 2 * d; ys[n] = cy - d
        xs[n + 1] = cx;     ys[n + 1] = cy + 2 * d
        xs[n + 2] = cx + 2 * d; ys[n + 2] = cy - d

        val tris = ArrayList<IntArray>()
        tris.add(intArrayOf(n, n + 1, n + 2))
        val bad = ArrayList<IntArray>()
        val edges = HashMap<Long, Int>()
        for (p in 0 until n) {
            bad.clear(); edges.clear()
            for (t in tris) if (inCircle(xs, ys, t, xs[p], ys[p])) bad.add(t)
            for (t in bad) for (e in 0..2) {
                val k = key(t[e], t[(e + 1) % 3])
                edges[k] = (edges[k] ?: 0) + 1
            }
            tris.removeAll(bad.toSet())
            for (t in bad) for (e in 0..2) {
                val a = t[e]; val b = t[(e + 1) % 3]
                if (edges[key(a, b)] == 1) tris.add(intArrayOf(a, b, p))
            }
        }
        val keep = tris.filter { it[0] < n && it[1] < n && it[2] < n }
        val out = ShortArray(keep.size * 3)
        for ((i, t) in keep.withIndex()) {
            out[3 * i] = t[0].toShort(); out[3 * i + 1] = t[1].toShort(); out[3 * i + 2] = t[2].toShort()
        }
        return out
    }
}
