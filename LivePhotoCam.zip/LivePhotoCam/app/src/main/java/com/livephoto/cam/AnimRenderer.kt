package com.livephoto.cam

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

const val CANVAS_W = 1080
const val CANVAS_H = 1920

class PhotoData(val bitmap: Bitmap, val srcUv: FloatArray, val tris: ShortArray, val nLm: Int)

/**
 * Warps the chosen photo with a triangle mesh: every landmark is moved by
 * (live landmark - neutral reference landmark) * scale, so the photo keeps its own identity
 * but copies your head motion + expressions. A procedural mouth interior (cavity, teeth, tongue)
 * is drawn inside the inner-lip contour.
 */
class AnimRenderer : GLSurfaceView.Renderer {
    @Volatile var face: FaceFrame? = null
    @Volatile var statusListener: ((String) -> Unit)? = null
    @Volatile private var pendingPhoto: PhotoData? = null
    @Volatile private var calibRequest = true

    private var photo: PhotoData? = null
    private var recorder: VideoRecorder? = null
    private var photoProg = 0
    private var mouthProg = 0
    private var tex = 0
    private var sw = 1
    private var sh = 1

    private var posBuf: FloatBuffer? = null
    private var uvBuf: FloatBuffer? = null
    private var idxBuf: ShortBuffer? = null
    private var dest = FloatArray(0)

    private val mouthBuf: FloatBuffer =
        ByteBuffer.allocateDirect(MOUTH_RING.size * 3 * 5 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private var mouthVerts = 0
    private var mouthHalfH = 0f
    private var tongue = 0f
    private val mX = FloatArray(MOUTH_RING.size)
    private val mY = FloatArray(MOUTH_RING.size)
    private val lX = FloatArray(MOUTH_RING.size)
    private val lY = FloatArray(MOUTH_RING.size)
    private var clipSx = 1f
    private var clipSy = 1f

    private var ref: FloatArray? = null
    private var refScale = 1f
    private var calibStart = 0L
    private var lastStatus = ""

    fun setPhoto(p: PhotoData) { pendingPhoto = p }
    fun recalibrate() { calibRequest = true }

    // ---------- GL lifecycle ----------
    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        photoProg = link(PHOTO_VS, PHOTO_FS)
        mouthProg = link(MOUTH_VS, MOUTH_FS)
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        tex = t[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        photo?.let { pendingPhoto = it } // re-upload after context loss
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { sw = width; sh = height }

    override fun onDrawFrame(gl: GL10?) {
        val np = pendingPhoto
        if (np != null) { pendingPhoto = null; applyPhoto(np) }

        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        val p = photo ?: return
        updateMesh(p)

        // 9:16 canvas, top-aligned on screen
        var vw = sw
        var vh = (sw * CANVAS_H.toFloat() / CANVAS_W).toInt()
        if (vh > sh) { vh = sh; vw = (sh * CANVAS_W.toFloat() / CANVAS_H).toInt() }
        GLES20.glViewport((sw - vw) / 2, sh - vh, vw, vh)
        drawScene()

        recorder?.draw {
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glViewport(0, 0, CANVAS_W, CANVAS_H)
            drawScene()
        }
    }

    // ---------- recording (GL thread) ----------
    fun startRecording(ctx: Context, mic: Boolean, onDone: (Uri?) -> Unit) {
        if (recorder != null) return
        try {
            val r = VideoRecorder(ctx, CANVAS_W, CANVAS_H, mic, onDone)
            r.attachEgl()
            r.start()
            recorder = r
        } catch (e: Exception) {
            Log.e(TAG, "startRecording", e)
            onDone(null)
        }
    }

    fun stopRecording() {
        recorder?.stop()
        recorder = null
    }

    // ---------- photo ----------
    private fun applyPhoto(p: PhotoData) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, p.bitmap, 0)
        if (p !== photo) {
            photo = p
            dest = p.srcUv.copyOf()
            uvBuf = floatBuf(p.srcUv)
            posBuf = ByteBuffer.allocateDirect(p.srcUv.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            idxBuf = ByteBuffer.allocateDirect(p.tris.size * 2).order(ByteOrder.nativeOrder())
                .asShortBuffer().apply { put(p.tris); position(0) }
            tongue = 0f
            calibRequest = true
        }
    }

    // ---------- per-frame mesh ----------
    private fun report(msg: String) {
        if (msg != lastStatus) { lastStatus = msg; statusListener?.invoke(msg) }
    }

    private fun updateMesh(p: PhotoData) {
        val f = face
        val pw = p.bitmap.width.toFloat()
        val ph = p.bitmap.height.toFloat()
        if (calibRequest) { calibRequest = false; ref = null; calibStart = 0L }

        if (f == null || f.pts.size < 2 * p.nLm) {
            if (ref == null) calibStart = 0L
            tongue *= 0.9f
            report("No face detected")
        } else {
            val r = ref
            if (r == null) {
                if (calibStart == 0L) calibStart = f.tsNs
                report("Hold a neutral face…")
                if (f.tsNs - calibStart > 1_500_000_000L) {
                    ref = f.pts.copyOf()
                    // landmarks 33 / 263 = outer eye corners -> face size ratio photo vs live
                    val live = hypot((f.pts[66] - f.pts[526]) * f.w, (f.pts[67] - f.pts[527]) * f.h)
                    val src = hypot((p.srcUv[66] - p.srcUv[526]) * pw, (p.srcUv[67] - p.srcUv[527]) * ph)
                    refScale = if (live > 1f) src / live else 1f
                }
            } else {
                val k = refScale
                for (i in 0 until p.nLm) {
                    dest[2 * i] = p.srcUv[2 * i] + k * (f.pts[2 * i] - r[2 * i]) * f.w / pw
                    dest[2 * i + 1] = p.srcUv[2 * i + 1] + k * (f.pts[2 * i + 1] - r[2 * i + 1]) * f.h / ph
                }
                tongue += (f.jawOpen - tongue) * 0.5f
                report("Live")
            }
        }

        // photo-UV -> clip space ("cover" the 9:16 canvas)
        val pa = pw / ph
        val ca = CANVAS_W.toFloat() / CANVAS_H
        if (pa >= ca) { clipSy = 1f; clipSx = pa / ca } else { clipSx = 1f; clipSy = ca / pa }
        val pb = posBuf ?: return
        pb.position(0)
        for (i in 0 until dest.size / 2) {
            pb.put((dest[2 * i] - 0.5f) * 2f * clipSx)
            pb.put(-(dest[2 * i + 1] - 0.5f) * 2f * clipSy)
        }
        pb.position(0)

        buildMouth(pw, ph)
    }

    private fun putMouthVert(u: Float, v: Float, lx: Float, ly: Float, depth: Float) {
        mouthBuf.put((u - 0.5f) * 2f * clipSx)
        mouthBuf.put(-(v - 0.5f) * 2f * clipSy)
        mouthBuf.put(lx); mouthBuf.put(ly); mouthBuf.put(depth)
    }

    private fun buildMouth(pw: Float, ph: Float) {
        val ring = MOUTH_RING
        val m = ring.size
        var cx = 0f
        var cy = 0f
        for (k in 0 until m) {
            mX[k] = dest[2 * ring[k]] * pw
            mY[k] = dest[2 * ring[k] + 1] * ph
            cx += mX[k]; cy += mY[k]
        }
        cx /= m; cy /= m
        var ex = mX[10] - mX[0]
        var ey = mY[10] - mY[0]
        val mw = hypot(ex, ey)
        mouthBuf.clear()
        if (mw < 2f) { mouthVerts = 0; return }
        ex /= mw; ey /= mw
        var vx = -ey
        var vy = ex
        if (vy < 0f) { vx = -vx; vy = -vy } // local +y always points "down the face"
        var minY = 1e9f
        var maxY = -1e9f
        for (k in 0 until m) {
            val dx = mX[k] - cx
            val dy = mY[k] - cy
            lX[k] = (dx * ex + dy * ey) / mw
            lY[k] = (dx * vx + dy * vy) / mw
            minY = min(minY, lY[k]); maxY = max(maxY, lY[k])
        }
        mouthHalfH = (maxY - minY) / 2f
        for (k in 0 until m) {
            val j = (k + 1) % m
            val da = hypot(lX[k], lY[k])
            val db = hypot(lX[j], lY[j])
            putMouthVert(dest[2 * ring[k]], dest[2 * ring[k] + 1], lX[k], lY[k], 0f)
            putMouthVert(dest[2 * ring[j]], dest[2 * ring[j] + 1], lX[j], lY[j], 0f)
            putMouthVert(cx / pw, cy / ph, 0f, 0f, (da + db) / 2f)
        }
        mouthBuf.position(0)
        mouthVerts = m * 3
    }

    // ---------- drawing ----------
    private fun drawScene() {
        val ib = idxBuf ?: return
        val pb = posBuf ?: return
        val ub = uvBuf ?: return

        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glUseProgram(photoProg)
        val aPos = GLES20.glGetAttribLocation(photoProg, "aPos")
        val aUv = GLES20.glGetAttribLocation(photoProg, "aUv")
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(photoProg, "uTex"), 0)
        pb.position(0); ub.position(0); ib.position(0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 8, pb)
        GLES20.glEnableVertexAttribArray(aUv)
        GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 8, ub)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, ib.capacity(), GLES20.GL_UNSIGNED_SHORT, ib)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aUv)

        if (mouthVerts > 0) {
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            GLES20.glUseProgram(mouthProg)
            val mPos = GLES20.glGetAttribLocation(mouthProg, "aPos")
            val mLocal = GLES20.glGetAttribLocation(mouthProg, "aLocal")
            val mDepth = GLES20.glGetAttribLocation(mouthProg, "aDepth")
            mouthBuf.position(0)
            GLES20.glEnableVertexAttribArray(mPos)
            GLES20.glVertexAttribPointer(mPos, 2, GLES20.GL_FLOAT, false, 20, mouthBuf)
            mouthBuf.position(2)
            GLES20.glEnableVertexAttribArray(mLocal)
            GLES20.glVertexAttribPointer(mLocal, 2, GLES20.GL_FLOAT, false, 20, mouthBuf)
            mouthBuf.position(4)
            GLES20.glEnableVertexAttribArray(mDepth)
            GLES20.glVertexAttribPointer(mDepth, 1, GLES20.GL_FLOAT, false, 20, mouthBuf)
            GLES20.glUniform1f(GLES20.glGetUniformLocation(mouthProg, "uHalfH"), mouthHalfH)
            GLES20.glUniform1f(GLES20.glGetUniformLocation(mouthProg, "uTongue"), tongue)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, mouthVerts)
            GLES20.glDisableVertexAttribArray(mPos)
            GLES20.glDisableVertexAttribArray(mLocal)
            GLES20.glDisableVertexAttribArray(mDepth)
            mouthBuf.position(0)
            GLES20.glDisable(GLES20.GL_BLEND)
        }
    }

    // ---------- helpers ----------
    private fun floatBuf(a: FloatArray): FloatBuffer =
        ByteBuffer.allocateDirect(a.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            .apply { put(a); position(0) }

    private fun compile(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Shader error: " + GLES20.glGetShaderInfoLog(s))
        return s
    }

    private fun link(vs: String, fs: String): Int {
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p)
        return p
    }

    companion object {
        private const val TAG = "AnimRenderer"

        // Inner-lip contour (MediaPipe indices): corner 78 ... corner 308 (index 10) ... back to 78
        val MOUTH_RING = intArrayOf(
            78, 191, 80, 81, 82, 13, 312, 311, 310, 415, 308,
            324, 318, 402, 317, 14, 87, 178, 88, 95
        )

        private const val PHOTO_VS = """
attribute vec2 aPos;
attribute vec2 aUv;
varying vec2 vUv;
void main() { vUv = aUv; gl_Position = vec4(aPos, 0.0, 1.0); }
"""
        private const val PHOTO_FS = """
precision mediump float;
varying vec2 vUv;
uniform sampler2D uTex;
void main() { gl_FragColor = texture2D(uTex, vUv); }
"""
        private const val MOUTH_VS = """
attribute vec2 aPos;
attribute vec2 aLocal;
attribute float aDepth;
varying vec2 vLocal;
varying float vDepth;
void main() { vLocal = aLocal; vDepth = aDepth; gl_Position = vec4(aPos, 0.0, 1.0); }
"""
        // vLocal is in "mouth widths" (x along the mouth, y down). vDepth = distance from the lip edge.
        private const val MOUTH_FS = """
precision mediump float;
varying vec2 vLocal;
varying float vDepth;
uniform float uHalfH;
uniform float uTongue;
void main() {
  vec3 col = mix(vec3(0.45, 0.09, 0.11), vec3(0.06, 0.0, 0.02), smoothstep(0.0, 0.20, vDepth));

  float cy = uHalfH * (0.55 - 0.30 * uTongue);
  vec2 q = vec2(vLocal.x / (0.20 + 0.06 * uTongue), (vLocal.y - cy) / max(uHalfH * 0.75, 0.001));
  float ql = length(q);
  float tm = 1.0 - smoothstep(0.80, 1.0, ql);
  vec3 tc = vec3(0.88, 0.38, 0.42) * (0.72 + 0.28 * (1.0 - ql));
  tc *= 1.0 - 0.25 * exp(-pow(vLocal.x * 28.0, 2.0));
  col = mix(col, tc, tm * 0.95);

  float up = step(vLocal.y, 0.0);
  float h = mix(0.085, 0.12, up);
  float side = 1.0 - smoothstep(0.34, 0.50, abs(vLocal.x));
  float tmask = (1.0 - smoothstep(h * 0.8, h, vDepth)) * side;
  float g = abs(fract(vLocal.x * 10.0) - 0.5);
  float gap = smoothstep(0.40, 0.5, g);
  float shade = 0.78 + 0.22 * sin(clamp(vDepth / h, 0.0, 1.0) * 3.14159);
  vec3 tooth = vec3(0.97, 0.96, 0.92) * shade * mix(0.92, 1.0, up);
  tooth = mix(tooth, vec3(0.62, 0.56, 0.52), gap * 0.55);
  col = mix(col, tooth, tmask);

  float a = smoothstep(0.0, 0.012, vDepth);
  gl_FragColor = vec4(col, a);
}
"""
    }
}
