package com.livephoto.cam

import android.graphics.Bitmap
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark

object PhotoPrep {
    /** Mesh = face landmarks + 12 fixed border points so the whole photo is drawn. */
    fun build(bmp: Bitmap, lm: List<NormalizedLandmark>): PhotoData {
        val n = lm.size
        val border = floatArrayOf(
            0f, 0f, .33f, 0f, .67f, 0f, 1f, 0f, 1f, .33f, 1f, .67f,
            1f, 1f, .67f, 1f, .33f, 1f, 0f, 1f, 0f, .67f, 0f, .33f
        )
        val total = n + border.size / 2
        val uv = FloatArray(total * 2)
        for (i in 0 until n) { uv[2 * i] = lm[i].x(); uv[2 * i + 1] = lm[i].y() }
        System.arraycopy(border, 0, uv, 2 * n, border.size)
        val xs = FloatArray(total) { uv[2 * it] * bmp.width }
        val ys = FloatArray(total) { uv[2 * it + 1] * bmp.height }
        return PhotoData(bmp, uv, Delaunay.triangulate(xs, ys, total), n)
    }
}
