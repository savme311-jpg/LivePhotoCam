package com.livephoto.cam

import kotlin.math.abs
import kotlin.math.max

/** One-Euro filter over a whole array: removes jitter when still, stays responsive when moving. */
class OneEuro(
    private val minCutoff: Float = 2.5f,
    private val beta: Float = 30f,
    private val dCutoff: Float = 1f
) {
    private var x: FloatArray? = null
    private var dx: FloatArray? = null
    private var tPrev = 0f

    fun reset() { x = null; dx = null }

    private fun alpha(cutoff: Float, dt: Float): Float {
        val tau = 1f / (2f * Math.PI.toFloat() * cutoff)
        return 1f / (1f + tau / dt)
    }

    fun apply(v: FloatArray, t: Float): FloatArray {
        val px = x
        val d = dx
        if (px == null || d == null || px.size != v.size) {
            x = v.copyOf(); dx = FloatArray(v.size); tPrev = t
            return v.copyOf()
        }
        val dt = max(t - tPrev, 1e-3f)
        tPrev = t
        val ad = alpha(dCutoff, dt)
        for (i in v.indices) {
            val rawD = (v[i] - px[i]) / dt
            d[i] = d[i] + ad * (rawD - d[i])
            val a = alpha(minCutoff + beta * abs(d[i]), dt)
            px[i] = px[i] + a * (v[i] - px[i])
        }
        return px.copyOf()
    }
}
