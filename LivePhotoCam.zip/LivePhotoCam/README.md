# Live Photo Cam
Pick a face photo -> the app animates it live from your front camera (head, eyes, brows, lips, jaw),
draws procedural teeth + tongue inside the mouth, and records 1080x1920 MP4 (with mic) to Movies/LivePhotoCam.

Build (no PC): put LivePhotoCam.zip + .github/workflows/build.yml in a GitHub repo, open Actions, download the APK artifact.
Best photos: front-facing, neutral closed mouth, good light.
